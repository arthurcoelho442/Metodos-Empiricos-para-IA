import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import norm
from cmdstanpy import CmdStanModel
import os
import tempfile

# ---------------------------
# CONFIGURAÇÕES
# ---------------------------

# Onde buscar os dados originais
files = {
    'furtoSimples': './sentencas_csv/furtoSimples.csv',
    'furtoQualificado': './sentencas_csv/furtoQualificado.csv',
    'roubo': './sentencas_csv/processos-roubo.csv',
    'trafico': './sentencas_csv/processos-trafico.csv'
}

# Pasta de saída
output_dir = "./saida"
os.makedirs(output_dir, exist_ok=True)

# ---------------------------
# PARTE 1 - PREPARAÇÃO DOS DADOS
# ---------------------------

all_dfs = {}

def convert_to_total_months(anos, meses, dias):
    try:
        years = pd.to_numeric(anos, errors='coerce')
        months = pd.to_numeric(meses, errors='coerce')
        days = pd.to_numeric(dias, errors='coerce')
        
        if pd.isna(years) and pd.isna(months) and pd.isna(days):
            return np.nan
        
        total_months = (years * 12 if not pd.isna(years) else 0) + \
                       (months if not pd.isna(months) else 0) + \
                       (days / 30.44 if not pd.isna(days) else 0)
        return total_months
    except:
        return np.nan

print("\n--- Preparando e limpando dados ---")
for crime_type, file_path in files.items():
    df = pd.read_csv(file_path, sep=';', quotechar='"')
    df.columns = df.columns.str.strip()
    
    df['Pena_Base_Meses'] = df.apply(lambda row: convert_to_total_months(row['anos_b'], row['meses_b'], row['dias_b']), axis=1)
    df['Pena_Definitiva_Meses'] = df.apply(lambda row: convert_to_total_months(row['anos_d'], row['meses_d'], row['dias_d']), axis=1)
    
    df_filtered = df[df['Pena_Definitiva_Meses'].notna() & (df['Pena_Definitiva_Meses'] > 0)].copy()
    df_filtered = df_filtered.dropna(subset=['Pena_Base_Meses', 'Pena_Definitiva_Meses']).drop_duplicates().copy()
    
    all_dfs[crime_type] = df_filtered
    
    if not df_filtered.empty:
        print(f"\nCrime: {crime_type}")
        desc_stats = df_filtered['Pena_Definitiva_Meses'].agg(['count', 'mean', 'median', 'std', 'min', 'max'])
        desc_stats['cv'] = desc_stats['std'] / desc_stats['mean'] * 100
        print(desc_stats.to_markdown())
    else:
        print(f"Sem dados válidos para {crime_type} após filtragem.")

# ---------------------------
# PARTE 2 - ANÁLISE COM CMDSTANPY
# ---------------------------

stan_model_code = """
data {
  int<lower=0> N;
  vector[N] y;
}
parameters {
  real mu;
  real<lower=0> sigma;
}
model {
  mu ~ normal(0, 10);
  sigma ~ cauchy(0, 2.5);
  y ~ normal(mu, sigma);
}
"""

with tempfile.TemporaryDirectory() as tmpdir:
    stan_file_path = os.path.join(tmpdir, "model.stan")
    with open(stan_file_path, "w") as f:
        f.write(stan_model_code)
    stan_model = CmdStanModel(stan_file=stan_file_path)

    all_stan_results = []

    for crime_type, df_crime in all_dfs.items():
        print(f"\n--- Analisando o crime: {crime_type} ---")
        if df_crime.empty or len(df_crime) < 5:
            print(f"Dados insuficientes para {crime_type} (N={len(df_crime)})")
            continue

        crime_data = df_crime["Pena_Definitiva_Meses"].values
        stan_data = {"N": len(crime_data), "y": crime_data}

        try:
            fit = stan_model.sample(
                data=stan_data,
                chains=4,
                iter_sampling=1000,
                iter_warmup=500,
                seed=123
            )

            mu_samples = fit.stan_variable("mu")
            sigma_samples = fit.stan_variable("sigma")

            all_stan_results.append({
                "Crime": crime_type,
                "N": len(crime_data),
                "Mean_mu": np.mean(mu_samples),
                "CI_mu_lower": np.percentile(mu_samples, 2.5),
                "CI_mu_upper": np.percentile(mu_samples, 97.5),
                "Mean_sigma": np.mean(sigma_samples),
                "CI_sigma_lower": np.percentile(sigma_samples, 2.5),
                "CI_sigma_upper": np.percentile(sigma_samples, 97.5)
            })

            # Distribuições posteriores
            plt.figure(figsize=(12, 6))
            plt.subplot(1, 2, 1)
            sns.histplot(mu_samples, kde=True, color="skyblue")
            plt.title(f"Distribuição Posterior da Média (mu)\n({crime_type})")

            plt.subplot(1, 2, 2)
            sns.histplot(sigma_samples, kde=True, color="lightcoral")
            plt.title(f"Distribuição Posterior do Desvio Padrão (sigma)\n({crime_type})")
            plt.tight_layout()
            filename_posterior = os.path.join(output_dir, f"posterior_distributions_{crime_type.lower().replace(' ', '_')}.png")
            plt.savefig(filename_posterior)
            plt.close()

            # Ajuste normal
            plt.figure(figsize=(10, 6))
            sns.histplot(crime_data, bins=15, kde=False, stat="density", color="skyblue", label="Dados")
            xmin, xmax = plt.xlim()
            x = np.linspace(xmin, xmax, 100)
            p = norm.pdf(x, np.mean(mu_samples), np.mean(sigma_samples))
            plt.plot(x, p, "k", linewidth=2, label="Ajuste Normal (cmdstanpy)")
            plt.title(f"Ajuste de Distribuição Normal ({crime_type})\nMédia = {np.mean(mu_samples):.2f}, DP = {np.mean(sigma_samples):.2f}")
            plt.legend()
            plt.grid(True)
            filename_fitted = os.path.join(output_dir, f"fitted_distribution_{crime_type.lower().replace(' ', '_')}.png")
            plt.savefig(filename_fitted)
            plt.close()

        except Exception as e:
            print(f"Erro ao processar {crime_type}: {e}")

if all_stan_results:
    summary_path = os.path.join(output_dir, "analysis_summary_refined.csv")
    pd.DataFrame(all_stan_results).to_csv(summary_path, index=False)
    print(f"\nResumo salvo em {summary_path}")
else:
    print("Nenhum resultado gerado.")
